"""Q TRUST Bell-state error-detection benchmark."""

from .analysis import analytic_acceptance, analytic_raw_fidelity
from .circuits import build_bell_experiment
from .experiment import ExperimentConfig, run_experiment
from .hardware import HardwareConfig, run_hardware_study

__all__ = [
    "ExperimentConfig",
    "HardwareConfig",
    "analytic_acceptance",
    "analytic_raw_fidelity",
    "build_bell_experiment",
    "run_experiment",
    "run_hardware_study",
]

